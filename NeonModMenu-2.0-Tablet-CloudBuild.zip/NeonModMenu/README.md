# NeonModMenu 2.0

A standalone Android Jetpack Compose settings dashboard for a Unity game you own or control. It stores preferences locally and exports a JSON configuration. It does not inject into, patch, or modify third-party games.

## Build without a PC (cloud build)

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Extract this ZIP on your Android tablet.
2. In a browser, create a GitHub repository.
3. Upload the **contents** of the `NeonModMenu` folder to the repository, keeping the folder structure (including `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab.
5. Select **Build NeonModMenu APK**, then choose **Run workflow** if it has not started automatically.
6. When the run finishes, open it and download the `NeonModMenu-debug-apk` artifact.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow uses Java 17, Gradle 8.11.1 and Android SDK 35. The output is a debug APK for testing, not a Play Store release.

## Build in Android Studio

1. Open this folder in Android Studio with Android SDK 35 installed.
2. Use JDK 17 and allow Gradle sync to complete.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Unity integration

The Export button shares JSON with these fields:
- `speed` (0.5–2.0)
- `theme`
- `visualEffects`
- `showFps`
- `version` (2)

Your Unity game must explicitly read and apply these settings. Exporting JSON does not change a game automatically.
