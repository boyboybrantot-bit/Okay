package com.cart3r.neonmenu.data

import android.content.Context

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("neon_settings", Context.MODE_PRIVATE)

    fun loadSpeed() = prefs.getFloat("game_speed", 1.0f).coerceIn(0.5f, 2.0f)
    fun saveSpeed(value: Float) {
        prefs.edit().putFloat("game_speed", value.coerceIn(0.5f, 2.0f)).apply()
    }

    fun loadTheme(): String {
        val value = prefs.getString("theme", "Blue Neon") ?: "Blue Neon"
        return value.takeIf { it in themes } ?: "Blue Neon"
    }
    fun saveTheme(value: String) {
        prefs.edit().putString("theme", value.takeIf { it in themes } ?: "Blue Neon").apply()
    }

    fun loadVisualEffects() = prefs.getBoolean("visual_effects", true)
    fun saveVisualEffects(value: Boolean) {
        prefs.edit().putBoolean("visual_effects", value).apply()
    }

    fun loadShowFps() = prefs.getBoolean("show_fps", false)
    fun saveShowFps(value: Boolean) {
        prefs.edit().putBoolean("show_fps", value).apply()
    }

    companion object {
        val themes = listOf("Blue Neon", "Purple Neon", "Red Neon", "Green Neon")
    }
}
