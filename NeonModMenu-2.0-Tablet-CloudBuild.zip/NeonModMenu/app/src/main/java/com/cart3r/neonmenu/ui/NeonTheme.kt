package com.cart3r.neonmenu.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun NeonTheme(themeName: String, content: @Composable () -> Unit) {
    val accent = when (themeName) {
        "Purple Neon" -> Color(0xFFB45CFF)
        "Red Neon" -> Color(0xFFFF4565)
        "Green Neon" -> Color(0xFF35F5A0)
        else -> Color(0xFF16A8FF)
    }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            secondary = accent,
            background = Color(0xFF050912),
            surface = Color(0xFF101827),
            onPrimary = Color(0xFF00111D),
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
