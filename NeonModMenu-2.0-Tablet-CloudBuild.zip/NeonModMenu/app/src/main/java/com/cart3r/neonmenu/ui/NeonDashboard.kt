package com.cart3r.neonmenu.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NeonDashboard(
    speed: Float,
    selectedTheme: String,
    visualEffects: Boolean,
    showFps: Boolean,
    onSpeedChange: (Float) -> Unit,
    onThemeChange: (String) -> Unit,
    onVisualEffectsChange: (Boolean) -> Unit,
    onShowFpsChange: (Boolean) -> Unit,
    onExport: () -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    Column(
        Modifier.fillMaxSize().background(Color(0xFF050912))
            .verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("CART3R  /  CONTROL", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text("NEON MOD MENU", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black)
        Text("GAME CONFIGURATION DASHBOARD", color = Color.Gray, fontSize = 11.sp)

        NeonCard(accent) {
            Text("SYSTEM STATUS", color = accent, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(50), color = Color(0xFF123D35)) {
                    Text("  ONLINE  ", color = Color(0xFF35F5A0), modifier = Modifier.padding(5.dp), fontSize = 11.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text("Configuration ready • v2.0", color = Color.LightGray, fontSize = 12.sp)
            }
        }

        NeonCard(accent) {
            Text("SPEED CONFIGURATION", color = accent, fontWeight = FontWeight.Bold)
            Text("${"%.2f".format(java.util.Locale.US, speed)}x", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Slider(value = speed, onValueChange = onSpeedChange, valueRange = 0.5f..2.0f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0.5x", color = Color.Gray, fontSize = 11.sp)
                Text("2.0x", color = Color.Gray, fontSize = 11.sp)
            }
            Text("Export this value for a game you own or control.", color = Color.Gray, fontSize = 11.sp)
        }

        NeonCard(accent) {
            Text("VISUAL OPTIONS", color = accent, fontWeight = FontWeight.Bold)
            SettingSwitch("Visual effects", "Enable visual effects in your game", visualEffects, onVisualEffectsChange)
            HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
            SettingSwitch("Show FPS", "Request an FPS counter in your game", showFps, onShowFpsChange)
        }

        NeonCard(accent) {
            Text("CUSTOM THEMES", color = accent, fontWeight = FontWeight.Bold)
            listOf("Blue Neon", "Purple Neon", "Red Neon", "Green Neon").forEach { theme ->
                Row(
                    Modifier.fillMaxWidth().clickable { onThemeChange(theme) }.padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(theme, color = Color.White)
                    RadioButton(selected = selectedTheme == theme, onClick = { onThemeChange(theme) })
                }
            }
        }

        Button(
            onClick = onExport,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("EXPORT UNITY CONFIG", fontWeight = FontWeight.Bold)
        }
        Text("CART3R • NEON MENU 2.0", color = accent, fontSize = 10.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun SettingSwitch(
    title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color.Gray, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun NeonCard(accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101827)),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f))
    ) {
        Column(Modifier.padding(18.dp), content = content)
    }
}
