package com.cart3r.neonmenu.unity

import org.json.JSONObject

data class GameConfiguration(
    val speed: Float,
    val theme: String,
    val visualEffects: Boolean,
    val showFps: Boolean
)

object UnityBridge {
    fun createConfiguration(configuration: GameConfiguration): String =
        JSONObject().apply {
            put("speed", configuration.speed.coerceIn(0.5f, 2.0f).toDouble())
            put("theme", configuration.theme)
            put("visualEffects", configuration.visualEffects)
            put("showFps", configuration.showFps)
            put("version", 2)
        }.toString(2)
}
