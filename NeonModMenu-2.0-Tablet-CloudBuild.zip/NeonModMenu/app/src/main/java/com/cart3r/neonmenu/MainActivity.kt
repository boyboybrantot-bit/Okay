package com.cart3r.neonmenu

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.cart3r.neonmenu.data.SettingsRepository
import com.cart3r.neonmenu.unity.GameConfiguration
import com.cart3r.neonmenu.unity.UnityBridge
import com.cart3r.neonmenu.ui.NeonDashboard
import com.cart3r.neonmenu.ui.NeonTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = SettingsRepository(applicationContext)

        setContent {
            var speed by remember { mutableFloatStateOf(repository.loadSpeed()) }
            var theme by remember { mutableStateOf(repository.loadTheme()) }
            var visualEffects by remember { mutableStateOf(repository.loadVisualEffects()) }
            var showFps by remember { mutableStateOf(repository.loadShowFps()) }

            NeonTheme(themeName = theme) {
                NeonDashboard(
                    speed = speed,
                    selectedTheme = theme,
                    visualEffects = visualEffects,
                    showFps = showFps,
                    onSpeedChange = {
                        speed = it.coerceIn(0.5f, 2.0f)
                        repository.saveSpeed(speed)
                    },
                    onThemeChange = {
                        theme = it
                        repository.saveTheme(it)
                    },
                    onVisualEffectsChange = {
                        visualEffects = it
                        repository.saveVisualEffects(it)
                    },
                    onShowFpsChange = {
                        showFps = it
                        repository.saveShowFps(it)
                    },
                    onExport = { shareConfiguration(speed, theme, visualEffects, showFps) }
                )
            }
        }
    }

    private fun shareConfiguration(
        speed: Float, theme: String, visualEffects: Boolean, showFps: Boolean
    ) {
        val json = UnityBridge.createConfiguration(
            GameConfiguration(speed, theme, visualEffects, showFps)
        )
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_TEXT, json)
        }
        startActivity(Intent.createChooser(sendIntent, "Export game configuration"))
    }
}
